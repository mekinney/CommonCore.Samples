import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'I am happy now';
  total = 10;
  doSomething() {
    this.total = 20;
  }
  testSomething() {
    this.total  = this.total + 10;
  }

}
